﻿namespace MVVM.ViewManager
{
    internal interface IUpdate
    {
        void OnUpdate();
    }
}
