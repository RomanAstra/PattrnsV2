﻿namespace MVVM.ViewManager
{
    public interface IViewModel
    {
    }
}
